<?php

	$lng['invalid_token'] = 'Erreur :: Token invalide';
	$lng['invalid_product'] = 'Erreur :: Produit invalide';
	$lng['bad_param'] ='Erreur :: Mauvais parametres ';
	$lng['invalid_price'] = 'Erreur :: Prix invalide';
	$lng['invalid_insert'] = 'Erreur :: Insertion invalide';
	$lng['win'] = 'Vous avez gagné ';
	$lng['invalid_panier'] ='Erreur :: Panier non valide';
	$lng['invalid_qte'] = 'Erreur :: Mauvais parametre de quantite';

	$lng['product_insert'] = 'Votre produit est insere';
	$lng['invalid_calcul'] = 'Erreur ::Calcul non specifie';
	$lng['invalid_country'] = 'Erreur :: Pays invalide';
	$lng['invalid_log'] ='Erreur :: log non specifie';
	$lng['invalid_email'] = 'Erreur :: Email non valide';
	$lng['logout'] = 'Au revoir';
	$lng['invalid_categ'] = 'Erreur :: Categorie non specifie';
	$lng['invalid_action'] = ' Erreur :: Action non specifie';
	$lng['invalid_bd'] = ' Erreur :: Connection au serveur impossible';
	$lng['choix_categ'] = ' Choisissez une catégorie ';
	$lng['choix_scateg'] = ' Choisissez une sous-catégorie';

	$lng['invalid_url'] = 'Erreur :: Url non valide';
	$lng['participation'] = 'Merci de votre contribution au site';
?>