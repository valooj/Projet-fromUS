<?php

	$lng['invalid_token'] = 'Error :: Token not specified or invalid';
	$lng['invalid_product'] = 'Error :: Product not specified';
	$lng['bad_param'] ='Error :: Bad parameters ';
	$lng['invalid_price'] = 'Error :: Price invalid';
	$lng['invalid_insert'] = 'Error :: Insert invalid';
	$lng['win'] = 'You win ';
	$lng['invalid_panier'] ='Error :: Panier not specified';
	$lng['invalid_qte'] = 'Error :: Bad Quantity parameter';

	$lng['product_insert'] = 'Your product is inserted';
	$lng['invalid_calcul'] = 'Error ::Calcul not specified';
	$lng['invalid_country'] = 'Error :: Country invalid';
	$lng['invalid_log'] ='Error :: log not specified';
	$lng['invalid_email'] = 'Error :: Email not valid';
	$lng['logout'] = 'Bye';
	$lng['invalid_categ'] = 'Error :: Category not specified';
	$lng['invalid_action'] = ' Error :: No action specified';
	$lng['invalid_bd'] = ' Error :: connection to the server could not';
	$lng['choix_categ'] = ' Choose a category';
	$lng['choix_scateg'] = ' Choose a sub-category';


?>